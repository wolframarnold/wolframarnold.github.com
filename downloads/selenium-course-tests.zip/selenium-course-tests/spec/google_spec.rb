require 'spec_helper'

describe "Google Search" do

  it "can find Selenium on Google" do
    page.open "/"
    page.title.should eql("Google")
    page.type "q", "Selenium seleniumhq"
    page.click "btnG", :wait_for => :page
    page.value("q").should eql("Selenium seleniumhq")
    page.text?("seleniumhq.org").should be_true
    page.title.should eql("Selenium seleniumhq - Google Search")
    page.text?("seleniumhq.org").should be_true
    page.element?("link=Cached").should be_true
  end

end
