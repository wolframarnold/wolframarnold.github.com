require 'spec_helper'

describe "Search Results" do
  before do
    @page = Homepage.visit.search_for('stationary')
    # @page is an object of the SearchResultsPage class
  end

  it 'returns "Shower Invitations Designer Cards" as a result' do
    @page.has_result?("Shower Invitations Designer Cards").should be_true
  end

#  it 'does something else'
#  it 'does some more...'

end
