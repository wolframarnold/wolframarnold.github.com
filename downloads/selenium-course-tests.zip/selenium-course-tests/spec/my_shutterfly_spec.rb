require 'spec_helper'

describe "My Shutterfly" do

  before do
    @page = Homepage.visit.
            click_sign_in.
            sign_in_as('fly@shutterfly.com', 'spork')
  end

  it 'has welcome sindhura message' do
    @page.has_welcome_message_for?('sindhura').should be_true
  end

end
