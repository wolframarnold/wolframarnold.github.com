require 'spec_helper'

describe "Popup in Share Album" do

  before do
    sign_in
  end

  it 'shows the popup' do
    page.click 'link=2010-06-16', :wait_for => :page
    page.click 'sharePictures', :wait_for => :element, :element => 'share-contenttop'
    page.click 'share-closeIcon', :wait_for => :no_element, :element => 'share-contenttop'
  end
end
