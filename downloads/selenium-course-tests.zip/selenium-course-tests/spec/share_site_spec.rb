require "spec_helper"

describe "Share site" do

  before do
    sign_in
    page.click "shareTab", :wait_for => :page
    page.click "css=div.share-section-bottom a.share-site-create", :wait_for => :page
    page.click "css=div.text-center a.a1", :wait_for => :page
  end

  it "shows Photo Journal section when clicking on Photo Journal link" do
    page.execution_delay = 1000
    page.click 'link=Photo Journal',
               :wait_for => :visible, :element => 'p_photo'
    page.visible?('p_photo').should be_true
    page.click 'link=Family',
               :wait_for => :visible, :element => 'p_family'
    page.execution_delay = 0
  end

end
