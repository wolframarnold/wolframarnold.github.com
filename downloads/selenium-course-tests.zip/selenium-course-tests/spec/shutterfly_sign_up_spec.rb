require 'spec_helper'

describe "sign up" do

  it 'should give me errors when I do not fill in the form' do
    page.open 'https://www.shutterfly.com/signup/viewSignup.sfly'
    page.click "signUpButton", :wait_for => :text, :text => 'Please correct the following errors, then resubmit the form'
    page.text?('Enter a first name for this account').should be_true
  end
end
