require 'spec_helper'

describe "Homepage" do

  before do
    @page = Homepage.visit
  end

  it 'has a sign in, sign up, help links' do
    @page.has_sign_in_link?.should be_true
    @page.has_sign_up_link?.should be_true
    @page.has_help_link?.should be_true
  end

  it 'has sub menu links' do
    @page.selenium_driver()
  end
end
