require 'spec_helper'

describe "Share Site Feature" do

  it 'can navigate to the "name site" page' do
    @page = Homepage.visit.            # on home page
            go_to_create_shared_site.  # on Create Share Site #1
            click_get_started.         # on Choose Template
            click_next.                # on Name Site
            on_name_site?.should be_true
  end

  it 'check that site name is available' do
    site_name = Digest::MD5.hexdigest(Time.now.to_s)

    @page = Homepage.visit.            # on home page
            go_to_create_shared_site.  # on Create Share Site #1
            click_get_started.         # on Choose Template
            click_next.                # on Name Site
            type_in_site_name(site_name).
            click_check_availability.
            url_available?.should be_true
  end

  it 'can create the site' do
    site_name = Digest::MD5.hexdigest(Time.now.to_s)

    @page = Homepage.visit.            # on home page
            go_to_create_shared_site.  # on Create Share Site #1
            click_get_started.         # on Choose Template
            click_next.                # on Name Site
            type_in_site_name(site_name).
            click_check_availability.
            click_next.                # on Sign up page
            click_on_sign_in.          # on Sign in page
            sign_in_as('fly@shutterfly.com', 'spork', ShareSitePage) # on Share Site page

    @page.get_url.should include(site_name)  # verifies that site_name is part of url
    @page.popup_present?.should be_true
    @page.get_popup_text_content.should include("Your site has been created")
  end

end
