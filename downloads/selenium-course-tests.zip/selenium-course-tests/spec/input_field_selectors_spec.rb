require 'spec_helper'

describe "Input Fields:" do
  before :all do
    @selenium_driver = Selenium::Client::Driver.new \
        :host => "localhost",
        :port => 4444,
        :browser => "*firefox",
        :url => "http://selenium-test-app.heroku.com/",
        :timeout_in_second => 30
  end
  before do
    page.open "/"
  end

  it "it advances when user name and email are filled out" do
    page.type "user_name", "Joe Smith"
    page.type "user_email", "joe@example.com"
    page.click "commit", :wait_for => :page
    page.title.should == 'Enter Suggestion'
  end

  it "stays on the same page with errors if name is missing" do
    page.type "user_email", "joe@example.com"
    page.click "commit", :wait_for => :page
    page.location.should match(/users$/)
    page.text?("Name can't be blank").should be_true
  end

  it 'reloads the input fields with previously entered data' do
    page.type "user_email", "joe@example.com"
    page.click "commit", :wait_for => :page
    page.field("user_email").should == "joe@example.com"    
  end

end
