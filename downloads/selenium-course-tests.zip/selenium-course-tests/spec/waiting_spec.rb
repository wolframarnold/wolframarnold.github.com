require 'spec_helper'

describe "Waiting" do

  before :each do
    page.open "http://localhost:3000"
    page.type "user[name]", "Joe Smith"
    page.type "user_email", "joe@example.com"
    page.click "user_submit", :wait_for => :page
    @url = page.location
  end

  it "can fill out the form and save the record" do
    page.open @url
    page.type 'record[title]', 'Must make coffee'
    page.select 'record[rating]', 'value=later'
    page.click "name=commit value=Create"

    page.wait_for :wait_for => :text, :element => 'css=td.title-column', :text => /Must make coffee/,
                  :timeout_in_seconds => 5

    # table: locator.row.column -- does not count header
    page.table_cell_text('css=#as_suggestions-content table.2.0').should == 'Must make coffee'
    page.table_cell_text('css=#as_suggestions-content table.2.1').should == 'later'
  end

end
