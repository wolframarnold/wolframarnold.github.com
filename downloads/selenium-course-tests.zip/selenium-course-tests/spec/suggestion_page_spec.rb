require 'spec_helper'

describe "Homepage" do

  before do
    @page = Homepage.visit.
            fill_in_name_and_email('joe', 'joe@example.com').
            click_submit
  end

  it 'can add suggestions' do
    @page.fill_in_title('hello world').
          click_submit.entry?('hello world').should be_true

  end
end
