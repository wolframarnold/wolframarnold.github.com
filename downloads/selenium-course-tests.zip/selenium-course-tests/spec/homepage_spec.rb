require 'spec_helper'

describe "Homepage" do

  before do
    @page = Homepage.visit
  end

  it 'can go on to suggestion page' do
    @page.fill_in_name_and_email('joe', 'joe@example.com').
          click_submit.should be_user_created_message

  end
end
