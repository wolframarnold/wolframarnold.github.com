require 'spec_helper'

describe "New Suggestion New User page" do

  before :all do
    @selenium_driver = Selenium::Client::Driver.new \
        :host => "localhost",
        :port => 4444,
        :browser => "*firefox",
        :url => "http://selenium-test-app.heroku.com/",
        :timeout_in_second => 30
  end
  before do
    page.open '/'
    page.type 'user_name', "Wolf"
  end

  it 'stays on the same page with errors if email is missing' do
    page.click 'commit', :wait_for => :page
    page.location.should match(/users$/)
    page.text?("Email can't be blank").should be_true
  end

  it 'moves to the next page when all fields are filled out' do
    page.type 'user_email', 'wolf@rubyfocus.biz'
    page.click 'commit', :wait_for => :page
    page.title.should eql('Enter Suggestion') # eql is same as ==
    page.location.should match(%r{users/\d+/suggestions/new})
  end
end
