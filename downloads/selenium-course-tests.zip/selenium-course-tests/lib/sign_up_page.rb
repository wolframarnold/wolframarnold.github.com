require 'page'

class SignUpPage < Page

  def click_on_sign_in
    selenium_driver.click("link=Sign in", :wait_for => :page)

    SignInPage.new
  end

end
