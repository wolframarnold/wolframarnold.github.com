require 'page'

class SignInPage < Page

  # ============================
  # Things to do on Sign In Page
  # ============================

  def initialize
    # When this object is created, we should be on the sign-in page.
    # Verify this by checking the title
    selenium_driver.title.should == "Sign in | Shutterfly"
  end

  def self.visit
    selenium_driver.open('/signin/viewSignin.sfly')
    SignInPage.new
  end

  def sign_in_as(username, password)
    selenium_driver.type "userName", username
    selenium_driver.type "password", password
    selenium_driver.click "signInButton", :wait_for => :page

    # We should now be on the MyShutterfly page, create that page object and return it
    MyShutterflyPage.new
  end

end
