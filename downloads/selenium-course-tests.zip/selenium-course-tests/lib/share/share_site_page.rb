require 'page'

class ShareSitePage < Page


  def popup_present?
    selenium_driver.wait_for :wait_for => :element, :element => 'dlg-1-frame'
    selenium_driver.element?('dlg-1-frame')
  end

  def get_popup_text_content
    selenium_driver.text('dlg-1-frame')
  end

  def get_url
    @url = selenium_driver.location
  end

end

class ShareSitePage2 < ShareSitePage
  # @url is available

  # get_url
  def get_url
    # overrides the parent's impelementation
    super # calls parent's get_url
  end
end
