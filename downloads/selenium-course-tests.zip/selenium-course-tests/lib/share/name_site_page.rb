require 'page'

class NameSitePage < Page

  # Action Methods
  # Things we can do here...

  def type_in_site_name(site_name)
    selenium_driver.type("title", site_name)

    self # return current page object, because we're not moving off the page
  end

  def click_check_availability
    selenium_driver.click("link=Check availability", {:wait_for => :text, :text => "This URL is available."})
    self
  end

  def click_next
    selenium_driver.click("css=div.buttons button.next", :wait_for => :page)

    SignUpPage.new
  end

  # Inspect Methods
  # Things we can see here...

  def get_web_site_url
    selenium_driver.value("groupName")
    self
  end

  def url_available?
    selenium_driver.text?("This URL is available.")
  end

  def on_name_site?
    selenium_driver.text?("Tell us about your site")
  end
end
