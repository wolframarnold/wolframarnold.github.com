require 'page'

class ChooseTemplatePage < Page

  def choose_template
  end

  def click_next
    selenium_driver.click("css=div.buttons button.next", {:wait_for => :visible, :element => 'step2'})

    NameSitePage.new
  end

end
