require 'page'

class CreateShareSiteStep1Page < Page

  def click_get_started
    selenium_driver.click("css=a.a1 img[src*=btn_getStarted]", :wait_for => :page)

    ChooseTemplatePage.new
  end
  
end
