require 'page'

class SuggestionPage < Page

  # ==============================
  # Things to do on SuggestionPage
  # ==============================

  def fill_in_title(title)
    @title = title
    selenium_driver.type "record[title]", @title
    self
  end

  def click_submit
    selenium_driver.click "commit", :wait_for => :text, :element => "css=tr.record td", :text => /#{@title}/
    self
  end

  # ===============================
  # Things to see on SuggestionPage
  # ===============================

  def user_created_message?
    selenium_driver.text?("Successfully created user.")
  end

  def entry?(text)
    selenium_driver.text?(text)
  end

end
