require 'page'

class Homepage < Page

  # =========================
  # Things to do on Home Page
  # =========================

  def self.visit
    selenium_driver.open('/')
    Homepage.new
  end

  def click_sign_in
    selenium_driver.click "link=Sign in", :wait_for => :page

    # We should now be on Sign In page:
    # Create SignInPage page object and return it (last expression in a method is returned)
    SignInPage.new
  end

  def search_for(search_term)
    selenium_driver.type 'q', search_term
    selenium_driver.click "css=input[name=q]+a"

    # verify we're on the search page
    selenium_driver.text?("Search results").should be_true

    SearchResultPage.new
  end

  # ==========================
  # Things to see on Home Page
  # ==========================

  def has_sign_in_link?
    selenium_driver.element?("link=Sign in")
  end

  def has_sign_up_link?
    selenium_driver.element?("link=Sign up")
  end

  def has_help_link?
    selenium_driver.element?("link=Help")
  end

  def get_nav_list
  end
end
