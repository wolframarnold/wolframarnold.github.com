require 'page'

class Homepage < Page

  # =========================
  # Things to do on Home Page
  # =========================

  def self.visit
    selenium_driver.open('/')
    Homepage.new
  end

  def fill_in_name_and_email(name,email)
    selenium_driver.type "user_name", name
    selenium_driver.type "user_email", email
    self
  end

  def click_submit
    selenium_driver.click "commit", :wait_for => :page

    # We should now be on Sign In page:
    # Create SignInPage page object and return it (last expression in a method is returned)
    SuggestionPage.new
  end

  # ==========================
  # Things to see on Home Page
  # ==========================

end
