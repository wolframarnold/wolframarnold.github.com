require 'page'

class SearchResultsPage < Page

  # Things to do on a Search Result Page

  # Things to see on a Search Result Page
  def has_result?(result_text)
    #selenium_driver.wait_for :wait_for => :text, :text => "Shower Invitations Designer Cards"
    selenium_driver.text?(result_text)
  end
end
