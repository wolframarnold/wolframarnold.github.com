require 'rubygems'
gem "rspec", ">=1.3.0"
require "spec"
gem "warnold-selenium-client", ">=1.2.19"
require "selenium/client"
require "selenium/rspec/spec_helper"

Spec::Example::ExampleGroup.class_eval do
  attr_reader :selenium_driver
  alias :page :selenium_driver
end

Spec::Runner.configure do |config|

  config.before(:all) do
      @selenium_driver = Selenium::Client::Driver.new \
          :host => "localhost",
          :port => 4444,
          :browser => "*firefox",
          :url => "http://www.shutterfly.com",
          :timeout_in_second => 60
  end

  config.prepend_before(:each) do
    selenium_driver.start_new_browser_session
  end

  # The system capture need to happen BEFORE closing the Selenium session
  config.append_after(:each) do
    @selenium_driver.close_current_browser_session
  end

  def click_sign_in_button
    page.click "signInButton", :wait_for => :page
  end

  def sign_in
    page.open "/"
    page.click "link=Sign in", :wait_for => :page
    page.title.should eql("Sign in | Shutterfly")
    page.type "userName", "fly@shutterfly.com"
    page.type "password", "spork"
    click_sign_in_button
  end
 
end
